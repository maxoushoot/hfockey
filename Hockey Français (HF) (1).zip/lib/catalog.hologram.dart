// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: unused_import
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/cupertino.dart';
import 'main.dart';
import "package:cached_network_image/cached_network_image.dart";
import "package:intl/intl.dart";
import "package:cupertino_icons/cupertino_icons.dart";
import "package:fl_chart/fl_chart.dart";
import "package:google_fonts/google_fonts.dart";
import "package:shared_preferences/shared_preferences.dart";
import "package:path_provider/path_provider.dart";
import "package:provider/provider.dart";
import "package:http/http.dart";
import "package:uuid/uuid.dart";
import "package:supabase_flutter/supabase_flutter.dart";
import "package:supabase/supabase.dart";
